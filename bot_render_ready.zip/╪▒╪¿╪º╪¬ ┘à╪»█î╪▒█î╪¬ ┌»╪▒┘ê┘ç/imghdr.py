# imghdr.py - shim for compatibility with old libraries
def what(file, h=None):
    return None
